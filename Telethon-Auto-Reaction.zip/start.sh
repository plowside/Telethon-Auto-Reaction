#!/bin/bash

while true; do
    timeout 2h python main.py
done